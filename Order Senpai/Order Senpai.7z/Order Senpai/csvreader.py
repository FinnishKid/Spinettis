import csv
import requests
import json
import pygsheets
import pandas as pd

gc = pygsheets.authorize(service_file='hehe.json')
df = pd.DataFrame()
sh = gc.open('12215928')
wks = sh[0]
values = []
order_num = 0
cust_name = ""
name = ""
sku = 0
quan = 0
storeurl = ""
channel = "Shopify"
date = ""

with open('trimmed.csv', newline='') as csvfile:
    reader = csv.DictReader(csvfile)
    
    for row in reader:
        order_num = row['Name']
        skusky = row['sku']
        quan = row['quantity']

        if skusky:
            url = ("https://api.sellbrite.com/v1/products/" + skusky)

            headers = {
                "Accept": "application/json",
                "Authorization": "Basic ODZjYmY1ZTgtYmFhOC00NmM2LWE2ZjItN2I5M2IzMGRlYTZlOmUxMGE0MjBhN2RmOWM2ZGI3NTBlZDdlNzE4NmU1Y2U0"
            }


            #2 api calls in 1 program? tripping balls my friend
            response = requests.get(url, headers=headers)

            chip_j = response.json()

            try:
                cat_name = chip_j["category_name"]
                storeurl = chip_j["store_product_url"]
                name = chip_j["name"]
                store_url = ["store_product_url"]
                #print(channel)
            except(KeyError):
                cat_name = ""
                #print("b")
                pass
            values.append([order_num, quan, name, skusky, storeurl, channel])
            if (cat_name == "Collector Chips"):
                #if everything is copasetic, adds stuff to the spreadsheet
                #print("a")
                wks.insert_rows(row =1, number=1, values =values)
            sku = ""
            cat_name = ""
            values = []
    



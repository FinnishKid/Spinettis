import requests
import json
import pygsheets
import pandas as pd

txt_file = open("orders.txt", "r")
orders_list = txt_file.readlines()
txt_file.close()

gc = pygsheets.authorize(service_file='hehe.json')

df = pd.DataFrame()
sh = gc.open('test')
wks = sh[0]

url = "https://api.sellbrite.com/v1/orders?page=1&limit=10"

headers = {
    "Accept": "application/json",
    "Authorization": "Basic ODZjYmY1ZTgtYmFhOC00NmM2LWE2ZjItN2I5M2IzMGRlYTZlOmUxMGE0MjBhN2RmOWM2ZGI3NTBlZDdlNzE4NmU1Y2U0"
}

response = requests.get(url, headers=headers)

res_j = response.json()

dic_1 = dict()
values = []
j = 0
ordernums = ["S1", "S2"]

while j < len(res_j):
    dict_1 = res_j[j]
    listthing = dict_1["items"]
    i = 0
    order_num = dict_1["display_ref"]
    while i < len(listthing):
        thing = dict(listthing[i])
        sku = thing["sku"]
        cust_name = dict_1["shipping_contact_name"]
        name = thing["title"]
        values.append([order_num, cust_name, name, sku])
        f = open("orders.txt", "a")
        f.write(order_num + "\n")
        f.close()

        i = i + 1
    j = j + 1
wks.append_table(values, start='A1', end=None, dimension='ROWS', overwrite=True)  

f = open("orders.txt", "a")
        f.write(order_num + "\n")
        f.close()








